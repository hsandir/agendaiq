-- DropIndex
DROP INDEX "District_code_key";

-- DropIndex
DROP INDEX "School_code_key";

-- DropIndex
DROP INDEX "User_staff_id_key";
